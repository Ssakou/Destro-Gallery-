package com.example.galleryapp

import android.Manifest
import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// -----------------------------------------------------------------------------
// 1. Data Model
// -----------------------------------------------------------------------------
data class GalleryItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val dateTaken: Long,
    val bucketName: String,
    val size: Long
)

// -----------------------------------------------------------------------------
// 2. UI State
// -----------------------------------------------------------------------------
data class GalleryUiState(
    val isLoading: Boolean = false,
    val photos: List<GalleryItem> = emptyList(),
    val albums: List<String> = listOf("All Photos"),
    val selectedAlbum: String = "All Photos",
    val selectedPhotoIndex: Int? = null,
    val hasPermission: Boolean = false
)

// -----------------------------------------------------------------------------
// 3. ViewModel
// -----------------------------------------------------------------------------
class GalleryViewModel(application: Application) : AndroidViewModel(application) {
    private val _uiState = MutableStateFlow(GalleryUiState())
    val uiState: StateFlow<GalleryUiState> = _uiState.asStateFlow()

    fun updatePermissionStatus(isGranted: Boolean) {
        _uiState.value = _uiState.value.copy(hasPermission = isGranted)
        if (isGranted) {
            loadPhotos()
        }
    }

    fun selectAlbum(albumName: String) {
        _uiState.value = _uiState.value.copy(selectedAlbum = albumName)
    }

    fun openViewer(index: Int) {
        _uiState.value = _uiState.value.copy(selectedPhotoIndex = index)
    }

    fun closeViewer() {
        _uiState.value = _uiState.value.copy(selectedPhotoIndex = null)
    }

    fun addPickedPhotos(uris: List<Uri>) {
        val currentPhotos = _uiState.value.photos.toMutableList()
        uris.forEachIndexed { idx, uri ->
            currentPhotos.add(
                0,
                GalleryItem(
                    id = System.currentTimeMillis() + idx,
                    uri = uri,
                    displayName = "Imported_${System.currentTimeMillis()}_$idx.jpg",
                    dateTaken = System.currentTimeMillis(),
                    bucketName = "Imported",
                    size = 0L
                )
            )
        }
        val albums = listOf("All Photos") + currentPhotos.map { it.bucketName }.distinct()
        _uiState.value = _uiState.value.copy(
            photos = currentPhotos,
            albums = albums
        )
    }

    fun loadPhotos() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        val context = getApplication<Application>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.SIZE
        )
        val sortOrder = "${MediaStore.Images.Media.DATE_TAKEN} DESC"

        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            val photoList = mutableListOf<GalleryItem>()
            val albumSet = mutableSetOf<String>()

            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
                val bucketColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val displayName = cursor.getString(nameColumn) ?: "IMG_$id"
                    val dateTaken = cursor.getLong(dateColumn)
                    val bucketName = cursor.getString(bucketColumn) ?: "Internal"
                    val size = cursor.getLong(sizeColumn)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    photoList.add(
                        GalleryItem(
                            id = id,
                            uri = contentUri,
                            displayName = displayName,
                            dateTaken = dateTaken,
                            bucketName = bucketName,
                            size = size
                        )
                    )
                    albumSet.add(bucketName)
                }
            }

            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    photos = photoList,
                    albums = listOf("All Photos") + albumSet.toList().sorted()
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 4. Main Activity & Root Composable
// -----------------------------------------------------------------------------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFD0BCFF),
                    onPrimary = Color(0xFF381E72),
                    surface = Color(0xFF141218),
                    onSurface = Color(0xFFE6E0E9),
                    surfaceVariant = Color(0xFF49454F),
                    onSurfaceVariant = Color(0xFFCAC4D0)
                )
            ) {
                GalleryAppScreen()
            }
        }
    }
}