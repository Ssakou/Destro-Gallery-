#!/usr/bin/env bash
set -euo pipefail

echo "========================================================"
echo "  Lumina Gallery (Android Jetpack Compose) APK Builder  "
echo "========================================================"

if command -v ./gradlew &> /dev/null; then
  GRADLE_CMD="./gradlew"
elif command -v gradle &> /dev/null; then
  GRADLE_CMD="gradle"
else
  echo "Error: Neither ./gradlew nor gradle was found in PATH."
  echo "Open this folder in Android Studio or install Gradle 8.9+ to compile."
  exit 1
fi

echo "-> Running $GRADLE_CMD assembleDebug..."
$GRADLE_CMD assembleDebug

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
  echo ""
  echo "SUCCESS! APK compiled at: $APK_PATH"
  if command -v adb &> /dev/null && adb get-state 1>/dev/null 2>&1; then
    echo "-> Connected Android device detected. Installing APK via adb..."
    adb install -r "$APK_PATH"
    echo "-> Installed on device!"
  fi
fi